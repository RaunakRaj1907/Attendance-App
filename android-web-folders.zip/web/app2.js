/* ================= WIZARD ================= */
function goStep(n){
  ['wStep1','wStep2','wStep3'].forEach((id,i)=>$(id).hidden=(i+1)!==n);
  ['wd1','wd2','wd3'].forEach((id,i)=>$(id).classList.toggle('on',i<n));
  $('wTitle').textContent=n===1?'1 · Attach timetable':n===2?'2 · Check what was built':'3 · Semester & target';
  $('wSub').textContent=n===1?'Excel only — classes & timings are read automatically':n===2?'Everything adapts to this timetable':'When do we count attendance?';
  if(n===2){UI.edCtx='wizard';renderEditor($('editor'))}
  if(n===3){$('semStart').value=S.semesterStart;$('semEnd').value=S.semesterEnd;$('semTarget').value=S.target}
  window.scrollTo(0,0);
}
function blankWeek(){
  const tt={};DAYS.forEach(d=>tt[d]=DEF_TIMES.map(t=>mkPeriod(t[0],t[1],t[0]==='11:00'?'LUNCH':'')));
  S.timetable=tt;S.dayEnabled={Mon:true,Tue:true,Wed:true,Thu:true,Fri:true,Sat:false,Sun:false};
}

/* ================= TIMETABLE EDITOR ================= */
function periodLabel(p){
  let s=p.start+'–'+p.end;
  if(p.periods>1||p.merged){const m=durMin(p.start,p.end);s+=' · '+m+' min ('+p.periods+' periods)'}
  return s;
}
function renderEditor(box){
  let h='';
  DAYS.forEach(d=>{
    const on=S.dayEnabled[d]!==false;
    const arr=dayPeriods(d);
    h+='<div class="daycard"><div class="dayhead"><button class="tgl '+(on?'on':'')+'" data-day="'+d+'" data-act="tgl"></button>'
      +'<span class="nm">'+d+'</span><span class="countpill">'+dayClassCount(d)+' classes</span></div>';
    if(on){
      arr.forEach((p,i)=>{
        const dur=p.merged||p.periods>1?'<span class="dur">'+durMin(p.start,p.end)+' min ('+p.periods+' periods)</span>':'';
        h+='<div class="per"><div class="timeln"><input data-day="'+d+'" data-i="'+i+'" data-f="start" value="'+esc(p.start)+'">–<input data-day="'+d+'" data-i="'+i+'" data-f="end" value="'+esc(p.end)+'">'+dur+'</div>'
          +'<div class="prow"><input class="subj" data-day="'+d+'" data-i="'+i+'" data-f="subject" placeholder="Subject or leave empty" value="'+esc(p.raw||p.subject||'')+'">'
          +'<button class="xbtn" data-day="'+d+'" data-i="'+i+'" data-act="del">✕</button></div>';
        if(p.type==='break')h+='<span class="badge brk">break — not counted</span>';
        if(p.type==='free')h+='<span class="badge freeb">free — not counted</span>';
        if(p.merged&&p.type==='class')h+='<span class="badge mrg">⛓ merged '+durMin(p.start,p.end)+'-min slot · counts as 1 class</span>';
        if(p.labOptions&&p.labOptions.length){
          h+='<div class="labbox"><div class="lt">▾ YOUR LAB</div><select data-day="'+d+'" data-i="'+i+'" data-f="lab">'
            +p.labOptions.map(o=>'<option value="'+esc(o.code)+'"'+(effSubj(p)===o.code?' selected':'')+'>'+esc(o.label)+'</option>').join('')+'</select>'
            +'<div class="fin">✓ finalised: '+esc(effSubj(p))+' in this slot</div></div>';
        }
        h+='<div class="minirow">';
        if(p.periods>1)h+='<button class="minibtn" data-day="'+d+'" data-i="'+i+'" data-act="split">✂ Split into '+p.periods+'</button>';
        else{
          const nx=arr[i+1];
          if(nx&&nx.type==='class'&&p.type==='class')h+='<button class="minibtn" data-day="'+d+'" data-i="'+i+'" data-act="merge">⛓ Merge with next (110-min · 1 class)</button>';
        }
        h+='</div></div>';
      });
      h+='<button class="addper" data-day="'+d+'" data-act="add">+ Add period</button>';
    }
    h+='</div>';
  });
  box.innerHTML=h;
  box.querySelectorAll('[data-act="tgl"]').forEach(b=>b.onclick=()=>{const d=b.dataset.day;S.dayEnabled[d]=S.dayEnabled[d]===false?true:false;save();renderEditor(box)});
  box.querySelectorAll('[data-act="del"]').forEach(b=>b.onclick=()=>{S.timetable[b.dataset.day].splice(+b.dataset.i,1);save();renderEditor(box)});
  box.querySelectorAll('[data-act="add"]').forEach(b=>b.onclick=()=>{
    const d=b.dataset.day,a=S.timetable[d];let s='8:15',e='9:10';
    if(a.length){const l=a[a.length-1];s=l.end;const m=tmin(s);if(m!=null){const t2=m+55;let hh=Math.floor(t2/60);if(hh>12)hh-=12;e=hh+':'+pad(t2%60)}}
    a.push(mkPeriod(s,e,''));save();renderEditor(box);
  });
  box.querySelectorAll('[data-act="merge"]').forEach(b=>b.onclick=()=>{
    const d=b.dataset.day,i=+b.dataset.i,a=S.timetable[d];const p=a[i],q=a[i+1];
    const np=mkPeriod(p.start,q.end,(p.raw||p.subject||'')+(normSub(p.subject)===normSub(q.subject)?'':' / '+(q.raw||q.subject||'')));
    np.periods=p.periods+q.periods;np.merged=true;a.splice(i,2,np);save();renderEditor(box);toast('Merged into 110-min slot = 1 class');
  });
  box.querySelectorAll('[data-act="split"]').forEach(b=>b.onclick=()=>{
    const d=b.dataset.day,i=+b.dataset.i,a=S.timetable[d];const p=a[i];
    const x=tmin(p.start),y=tmin(p.end);if(x==null||y==null)return;
    const n=p.periods,step=Math.round((y-x)/n);const out=[];
    for(let k=0;k<n;k++){const f1=x+step*k,f2=k===n-1?y:x+step*(k+1);
      const f=h=>(h>12?h-12:h);
      out.push(mkPeriod(f(Math.floor(f1/60))+':'+pad(f1%60),f(Math.floor(f2/60))+':'+pad(f2%60),p.raw||p.subject||''))}
    a.splice(i,1,...out);save();renderEditor(box);
  });
  box.querySelectorAll('input[data-f],select[data-f]').forEach(el=>{
    el.onchange=()=>{
      const d=el.dataset.day,i=+el.dataset.i,f=el.dataset.f,p=S.timetable[d][i];if(!p)return;
      if(f==='lab'){p.labChoice=el.value;save();renderEditor(box);return}
      if(f==='subject'){p.subject=el.value;p.raw=el.value;retype(p)}
      else p[f]=el.value;
      save();renderEditor(box);
    };
  });
}

/* ================= ATTENDANCE CORE ================= */
function rec(ds){return S.attendance[ds]||null}
function getRec(ds){if(!S.attendance[ds])S.attendance[ds]={marks:{},extra:[]};return S.attendance[ds]}
function isHoliday(ds){return S.holidays.some(h=>h.date===ds)}
function schedFor(ds){
  const d=dowLong(ds);
  if(S.dayEnabled[d]===false)return [];
  return classPeriods(d);
}
// classify a date: held classes with present/absent resolution
function dayResult(ds){
  const r=rec(ds);
  if(isHoliday(ds))return {excluded:true,reason:'holiday'};
  if(r&&(r.status==='closed'||r.status==='holiday'||r.status==='exam'||r.status==='prepleave'))return {excluded:true,reason:r.status};
  const sch=schedFor(ds);
  const items=sch.map(p=>({pid:p.id,subject:effSubj(p),time:p.start+'–'+p.end,lab:p.labOptions&&p.labOptions.length>0}));
  const extras=(r&&r.extra||[]).map(x=>({pid:x.id,subject:x.subject,time:x.time||'Extra',extra:true}));
  if(!r&&(items.length===0))return {excluded:true,reason:'noclass'};
  if(!r)return {held:true,unmarked:true,scheduled:items,extras:[],present:[],absent:[]};
  const present=[],absent=[],unm=[];
  if(r.status==='attended'){items.forEach(it=>present.push(it))}
  else if(r.status==='missed'){items.forEach(it=>absent.push(it))}
  else{items.forEach(it=>{const v=r.marks[it.pid];if(v===true)present.push(it);else if(v===false)absent.push(it);else unm.push(it)})}
  (r.extra||[]).forEach(x=>{
    const it={pid:x.id,subject:x.subject,time:x.time||'Extra',extra:true};
    if(x.present===true)present.push(it);else if(x.present===false)absent.push(it);
  });
  const marked=present.length+absent.length;
  if(marked===0)return {held:true,unmarked:true,scheduled:items,extras:extras,present:[],absent:[]};
  return {held:true,scheduled:items,extras:extras,present,absent,partial:unm.length>0&&marked>0};
}
function dayStatus(ds){
  const t=todayStr();
  if(isHoliday(ds))return 'hol';
  const r=rec(ds);
  if(r&&r.status==='closed')return 'cls';
  if(r&&r.status==='holiday')return 'hol';
  if(r&&r.status==='exam')return 'exam';
  if(r&&r.status==='prepleave')return 'prep';
  if(schedFor(ds).length===0&&!(r&&r.extra&&r.extra.length))return 'off';
  if(ds>t&&!r)return 'off';
  const res=dayResult(ds);
  if(res.excluded)return res.reason==='holiday'?'hol':res.reason==='closed'?'cls':'off';
  if(res.unmarked)return '';
  if(res.absent.length===0)return 'att';
  if(res.present.length===0)return 'mis';
  return 'par';
}
function computeStats(){
  const per={};let T=0,A=0;
  const acc=(subj,pres)=>{const k=normSub(subj);if(!k)return;per[k]=per[k]||{name:String(subj).trim(),t:0,a:0};per[k].t++;T++;if(pres){per[k].a++;A++}};
  Object.keys(S.attendance).forEach(ds=>{
    const res=dayResult(ds);if(res.excluded||res.unmarked)return;
    res.present.forEach(it=>acc(it.subject,true));res.absent.forEach(it=>acc(it.subject,false));
  });
  return {per,T,A};
}
function skipMath(a,t,target){
  target=target||S.target;
  if(t===0)return {txt:'—',cls:'g'};
  const pct=a/t*100;
  if(pct<target){const need=Math.ceil((target*t-100*a)/(100-target));return {txt:'need '+need+' in a row',cls:'r'}}
  const can=Math.floor(a*100/target-t);return {txt:can+' class'+(can===1?'':'es'),cls:can===0?'r':'g',zero:can===0};
}
/* ---- exams ---- */
function examDates(){
  return Object.keys(S.attendance||{}).filter(ds=>S.attendance[ds]&&S.attendance[ds].status==='exam').sort()
    .map(ds=>({ds:ds,title:(S.attendance[ds].examTitle||'Exam')}));
}
function autoFillPrep(){
  const exams=examDates().map(e=>e.ds).filter(ds=>ds>=S.semesterStart&&ds<=S.semesterEnd);
  let n=0;
  for(let i=0;i+1<exams.length;i++){
    const d=parseD(exams[i]);d.setDate(d.getDate()+1);
    while(dstr(d)<exams[i+1]){
      const ds=dstr(d);const r=S.attendance[ds];
      const untouched=!r||(!r.status&&!Object.keys(r.marks||{}).length&&!(r.extra||[]).length);
      if(untouched&&!isHoliday(ds)){S.attendance[ds]={status:'prepleave',marks:{},extra:[]};n++}
      d.setDate(d.getDate()+1);
    }
  }
  save();return n;
}
