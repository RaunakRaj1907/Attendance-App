/* ================= TABS ================= */
function setTab(t){
  UI.tab=t;
  document.querySelectorAll('#bottomNav button').forEach(b=>b.classList.toggle('on',b.dataset.tab===t));
  ['dashboard','today','calendar','schedule','settings'].forEach(x=>$('tab-'+x).hidden=x!==t);
  if(t==='dashboard')renderDash();if(t==='today')renderToday();if(t==='calendar')renderCal();
  if(t==='schedule')renderSched();if(t==='settings')renderSettings();
  window.scrollTo(0,0);
}
function refreshHead(){}

/* ================= DASHBOARD ================= */
function renderDash(){
  refreshHead();
  const st=computeStats();const pct=st.T?st.A/st.T*100:0;
  const C=2*Math.PI*54;
  const allS=allSubjects();
  // include subjects with 0 held classes too
  allS.forEach(s=>{const k=normSub(s);if(!st.per[k])st.per[k]={name:s,t:0,a:0}});
  const sk=skipMath(st.A,st.T);
  let h='<div class="card"><h4>Overall attendance</h4><div class="ringwrap"><div class="ring">'
    +'<svg width="130" height="130"><circle cx="65" cy="65" r="54" fill="none" stroke="#222c52" stroke-width="13"/>'
    +'<circle cx="65" cy="65" r="54" fill="none" stroke="'+(pct>=S.target?'#2dd4a6':'#fbbf24')+'" stroke-width="13" stroke-linecap="round" stroke-dasharray="'+(C*pct/100)+' '+C+'"/></svg>'
    +'<div class="pct"><b>'+pct.toFixed(1)+'%</b><span>ATTENDED</span></div></div>'
    +'<div style="flex:1"><div class="statline"><span>Total classes</span><b>'+st.T+'</b></div>'
    +'<div class="statline"><span>Attended</span><b class="g">'+st.A+'</b></div>'
    +'<div class="statline"><span>Missed</span><b class="r">'+(st.T-st.A)+'</b></div>'
    +'<div class="statline"><span>Target</span><b>'+S.target+'%</b></div></div></div></div>';
  const upcoming=examDates().filter(e=>e.ds>=todayStr()).slice(0,3);
  if(upcoming.length){
    h+='<div class="card"><h4>Upcoming exams</h4>';
    upcoming.forEach(e=>{
      const diff=Math.round((parseD(e.ds)-parseD(todayStr()))/86400000);
      const when=diff===0?'today!':diff===1?'tomorrow':'in '+diff+' days';
      h+='<div class="skipline"><span>📝 '+esc(e.title)+'<br><span class="small">'+fmtDs(e.ds)+'</span></span><b class="a">'+when+'</b></div>';
    });
    h+='<p class="small">Exam days & prep leaves are excluded from attendance.</p></div>';
  }
  h+='<div class="card"><h4>Subject-wise attendance</h4>';
  if(!Object.keys(st.per).length)h+='<p class="mut">No subjects yet — add your timetable first.</p>';
  Object.keys(st.per).sort().forEach(k=>{
    const p=st.per[k];const q=p.t?p.a/p.t*100:0;
    const badge=!p.t?'<span class="pill low">No data</span>':q>=S.target?'<span class="pill safe">Safe</span>':q>=S.target-10?'<span class="pill low">Low</span>':'<span class="pill dan">Risk</span>';
    h+='<div class="subj"><div class="top"><span class="dot" style="background:'+subjColor(p.name)+';color:'+subjColor(p.name)+'"></span><b>'+esc(p.name)+'</b><span class="pc '+(q>=S.target||!p.t?'g':'a')+'">'+(p.t?q.toFixed(2)+'%':'—')+'</span></div>'
      +'<div class="bar"><i style="width:'+q+'%;background:'+(q>=S.target?'var(--grn)':q>=S.target-10?'var(--amb)':'var(--red)')+'"></i></div>'
      +'<div class="bot"><span>'+p.a+'/'+p.t+' classes · '+weeklyPossible(p.name)+'/week possible</span>'+badge+'</div></div>';
  });
  h+='</div>';
  h+='<div class="card"><h4>How many classes can you skip?</h4>'
    +'<p style="font-size:15px;line-height:1.6">Based on the <b>'+st.T+'</b> classes you\'ve had so far, you can skip up to <b class="'+sk.cls+'">'+sk.txt+'</b> and still stay at or above '+S.target+'%.</p>'
    +'<p class="small" style="margin:6px 0 8px">Only classes already held are counted — future classes are not included. Extra classes you add are included.</p>';
  Object.keys(st.per).sort().forEach(k=>{
    const p=st.per[k];if(!p.t)return;const s=skipMath(p.a,p.t);
    h+='<div class="skipline"><span>'+esc(p.name)+'</span><b class="'+s.cls+'">'+(s.zero?'0 — at the limit':s.txt)+'</b></div>';
  });
  h+='</div>';
  $('tab-dashboard').innerHTML=h;
}

/* ================= SLIDING SWITCH COMPONENT ================= */
function swState(v){return v===true?'on':v===false?'off':'mid'}
function swHTML(pid,state,isExtra,small){
  const m=state==='on'?['present','Present']:state==='off'?['missed','Missed']:['unset','Not set'];
  return '<div class="swwrap"><button class="sw '+state+(small?' sm':'')+'" data-sw="'+pid+'"'+(isExtra?' data-x="1"':'')+'><span class="knob"></span></button><span class="swlab '+m[0]+'">'+m[1]+'</span></div>';
}
function todayEff(rr,pid){
  if(rr.status==='attended')return true;
  if(rr.status==='missed')return false;
  return rr.marks[pid];
}

/* ================= TODAY ================= */
function renderToday(){
  refreshHead();
  if(!UI.todayDate)UI.todayDate=todayStr();
  const ds=UI.todayDate,d=dowLong(ds),sch=schedFor(ds),r=getRec(ds);
  let h='<div class="card"><h4>Mark today\'s attendance</h4><div class="datehead"><input type="date" id="todayDate" value="'+ds+'"><span class="daychip">'+d+'</span></div></div>';
  h+='<div class="card"><h4>Classes on '+dowLong(ds)+', '+parseD(ds).getDate()+' '+parseD(ds).toLocaleDateString('en-IN',{month:'short'})+'</h4>';
  if(!sch.length&&!(r.extra||[]).length)h+='<p class="mut">No classes scheduled. Enjoy the day off — or add an extra class below.</p>';
  else{
    let np=0,nm=0,nu=0;
    sch.forEach(p=>{const v=todayEff(r,p.id);if(v===true)np++;else if(v===false)nm++;else nu++});
    (r.extra||[]).forEach(x=>{if(x.present===true)np++;else if(x.present===false)nm++;else nu++});
    h+='<p class="small" style="margin:2px 0 8px">👉 <b>Slide a switch</b> to mark that class — <b class="g">✓ '+np+' present</b> · <b class="r">✕ '+nm+' missed</b>'+(nu?' · <b>○ '+nu+' not set</b>':'')+'</p>';
  }
  sch.forEach((p,i)=>{
    const s=effSubj(p);const c=subjColor(s);
    h+='<div class="clsrow"><span class="numb" style="background:'+c+'">'+(i+1)+'</span><div class="inf"><b>'+esc(s)+'</b><div>'+p.start+'–'+p.end+(p.periods>1?' · '+durMin(p.start,p.end)+' min (counts as 1)':'')+(p.labOptions&&p.labOptions.length?' · ✓ your lab':'')+'</div></div>'+swHTML(p.id,swState(todayEff(r,p.id)),false,false)+'</div>';
  });
  h+='<div id="todayExtras">';
  (r.extra||[]).forEach(x=>{h+=extraRowHTML(x)});
  h+='</div>';
  h+='<button class="btn sm" id="btnAddExtra">＋ Add extra class (counts in attendance)</button>';
  h+='<button class="btn green" id="tAll">✅ All attended</button><button class="btn red" id="tNone">❌ None attended</button>'
    +'<button class="btn" id="tSave">💾 Save class-level marks</button>'
    +'<div class="row2"><button class="btn sm ghost" id="tClosed">🏫 College closed</button><button class="btn sm ghost" id="tOff">🎉 Took off</button></div>'
    +'<div class="row2"><button class="btn sm ghost" id="tExam">📝 Exam day</button><button class="btn sm ghost" id="tPrep">📚 Prep leave</button></div>'
    +'<button class="btn sm ghost" id="tClear">↩️ Clear this day</button></div>';
  h+='<div class="card"><h4>Need to make it up later? Pick any date</h4><p class="mut">Use the date box above or the Calendar tab to back-fill any day. Extra classes work on any date.</p></div>';
  $('tab-today').innerHTML=h;
  $('todayDate').onchange=e=>{UI.todayDate=e.target.value;renderToday()};
  $('tab-today').querySelectorAll('.sw[data-sw]:not([data-x])').forEach(b=>b.onclick=()=>{
    const pid=b.dataset.sw;
    if(r.status==='attended'||r.status==='missed'){
      const v=r.status==='attended';
      sch.forEach(p=>{r.marks[p.id]=v});
      r.status=undefined;r.marks[pid]=!v;
    }else{
      const cur=r.marks[pid];
      r.marks[pid]=cur===undefined?true:cur===true?false:undefined;
    }
    save();renderToday();
  });
  bindExtraList($('tab-today'),ds,()=>renderToday());
  $('btnAddExtra').onclick=()=>openExtraModal(ds,()=>renderToday());
  $('tAll').onclick=()=>{const rr=getRec(ds);rr.status='attended';rr.marks={};save();renderToday();toast('Marked all attended ✓')};
  $('tNone').onclick=()=>{const rr=getRec(ds);rr.status='missed';rr.marks={};save();renderToday();toast('Marked all missed')};
  $('tSave').onclick=()=>{const rr=getRec(ds);rr.status=undefined;save();renderToday();toast('Saved ✓')};
  $('tClosed').onclick=()=>{const rr=getRec(ds);rr.status='closed';save();renderToday();toast('Day excluded (college closed)')};
  $('tOff').onclick=()=>{const rr=getRec(ds);rr.status='holiday';save();renderToday();toast('Day excluded (personal off)')};
  $('tExam').onclick=()=>{const rr=getRec(ds);rr.status='exam';if(!rr.examTitle)rr.examTitle='Exam';save();renderToday();toast('📝 Exam day — excluded from attendance')};
  $('tPrep').onclick=()=>{const rr=getRec(ds);rr.status='prepleave';save();renderToday();toast('📚 Prep leave — excluded from attendance')};
  $('tClear').onclick=()=>{delete S.attendance[ds];save();renderToday();toast('Day cleared')};
}
function extraRowHTML(x){
  const st=x.present===false?'off':x.present===true?'on':'mid';
  const lab=st==='on'?['present','Present']:st==='off'?['missed','Missed']:['unset','Not set'];
  return '<div class="xcls"><span class="badge lab">extra</span><span><b>'+esc(x.subject)+'</b><br><span class="small">'+esc(x.time||'Extra')+' · counts as 1 class</span></span>'
    +'<span style="margin-left:auto"></span><div class="swwrap"><button class="sw '+st+' sm" data-xid="'+x.id+'"><span class="knob"></span></button><span class="swlab '+lab[0]+'">'+lab[1]+'</span></div>'
    +'<button class="minibtn" style="flex:0 0 auto" data-xdel="'+x.id+'">Delete</button></div>';
}
function bindExtraList(root,ds,rerender){
  root.querySelectorAll('[data-xid]').forEach(b=>b.onclick=()=>{
    const rr=getRec(ds);const x=(rr.extra||[]).find(e=>e.id===b.dataset.xid);if(!x)return;
    x.present=(x.present===undefined||x.present===null)?true:!x.present;
    rr.status=undefined;save();rerender();
  });
  root.querySelectorAll('[data-xdel]').forEach(b=>b.onclick=()=>{
    const rr=getRec(ds);rr.extra=(rr.extra||[]).filter(e=>e.id!==b.dataset.xdel);save();rerender();
  });
}

/* ---- extra class modal ---- */
function openExtraModal(ds,cb){
  const subs=allSubjects();
  $('extraBox').innerHTML='<h3 style="margin-bottom:4px">＋ Add extra class</h3><p class="mut">'+fmtDs(ds)+' · included in attendance as 1 class</p>'
    +'<label class="lbl">Subject</label><input id="exSubj" list="subjList" placeholder="e.g. PHL"><datalist id="subjList">'+subs.map(s=>'<option value="'+esc(s)+'">').join('')+'</datalist>'
    +'<label class="lbl">Time (optional)</label><input id="exTime" placeholder="e.g. 3:15–4:10" value="Extra">'
    +'<label class="lbl">Status</label><select id="exPres"><option value="1">Attended ✓</option><option value="0">Missed ✕</option></select>'
    +'<button class="btn primary" id="exSave">Add to '+fmtDs(ds)+'</button><button class="btn ghost sm" id="exCancel">Cancel</button>';
  $('extraWrap').hidden=false;
  $('exCancel').onclick=()=>$('extraWrap').hidden=true;
  $('extraWrap').onclick=e=>{if(e.target.id==='extraWrap')$('extraWrap').hidden=true};
  $('exSave').onclick=()=>{
    const s=$('exSubj').value.trim();if(!s){toast('Enter a subject');return}
    const rr=getRec(ds);rr.extra=rr.extra||[];
    rr.extra.push({id:uid('x'),subject:s,time:$('exTime').value.trim()||'Extra',present:$('exPres').value==='1'});
    if(rr.status==='closed'||rr.status==='holiday')rr.status=undefined;
    save();$('extraWrap').hidden=true;toast('Extra class added ✓');cb&&cb();
  };
}

/* ================= CALENDAR ================= */
function renderCal(){
  refreshHead();
  const t=new Date();
  if(!UI.calY){UI.calY=t.getFullYear();UI.calM=t.getMonth()}
  const Y=UI.calY,M=UI.calM;
  const mName=new Date(Y,M,1).toLocaleDateString('en-IN',{month:'long',year:'numeric'});
  let h='<div class="card"><h4>Tap a day to record what happened</h4><div class="calnav"><button id="cPrev">◀</button><b>'+mName+'</b><button id="cNext">▶</button></div><div class="calgrid">';
  ['SU','MO','TU','WE','TH','FR','SA'].forEach(d=>h+='<div class="dw">'+d+'</div>');
  const lead=(new Date(Y,M,1).getDay());
  for(let i=0;i<lead;i++)h+='<button class="cday off" disabled></button>';
  const dim=new Date(Y,M+1,0).getDate();
  for(let dd=1;dd<=dim;dd++){
    const ds=Y+'-'+pad(M+1)+'-'+pad(dd);const st=dayStatus(ds);
    const cls=st==='att'?'att':st==='mis'?'mis':st==='par'?'par':st==='cls'?'cls':st==='hol'?'hol':st==='exam'?'exam':st==='prep'?'prep':(schedFor(ds).length?'':'off');
    h+='<button class="cday '+cls+(ds===todayStr()?' sel':'')+'" data-ds="'+ds+'">'+dd+'</button>';
  }
  h+='</div><div class="legend"><span><i style="background:var(--grn)"></i>Attended</span><span><i style="background:var(--red)"></i>Missed</span><span><i style="background:#aab4ff"></i>Partial</span><span><i style="background:#9aa3c7"></i>Closed</span><span><i style="background:var(--amb)"></i>Holiday</span><span><i style="background:#a855f7"></i>Exam</span><span><i style="background:#38bdf8"></i>Prep leave</span><span><i style="background:#3a466f"></i>No class</span></div></div>';
  const exs=examDates();
  h+='<div class="card"><h4>📝 Exams (excluded from attendance)</h4>'
    +(exs.length?exs.map(e=>'<div class="holrow"><span>📝 '+e.ds+' — <b>'+esc(e.title)+'</b></span><button data-exdel="'+e.ds+'">✕</button></div>').join(''):'<p class="mut">No exams yet — add a day or a whole date range below.</p>')
    +'<div class="row2" style="margin-top:10px"><span><label class="lbl" style="margin:0 0 5px">From</label><input type="date" id="exFrom"></span><span><label class="lbl" style="margin:0 0 5px">To (empty = 1 day)</label><input type="date" id="exTo"></span></div>'
    +'<label class="lbl">Exam name (applies to all days)</label><input id="exTitle" placeholder="e.g. End-sem exams">'
    +'<button class="btn primary sm" id="exAdd">Add exam day(s)</button>'
    +'<button class="btn ghost sm" id="prepAuto">📚 Auto-mark prep leaves between exams</button></div>';
  $('tab-calendar').innerHTML=h;
  $('cPrev').onclick=()=>{UI.calM--;if(UI.calM<0){UI.calM=11;UI.calY--}renderCal()};
  $('cNext').onclick=()=>{UI.calM++;if(UI.calM>11){UI.calM=0;UI.calY++}renderCal()};
  $('tab-calendar').querySelectorAll('[data-exdel]').forEach(b=>b.onclick=()=>{delete S.attendance[b.dataset.exdel];save();renderCal()});
  $('exAdd').onclick=()=>{
    let a=$('exFrom').value,b=$('exTo').value||$('exFrom').value;
    if(!a){toast('Pick a start date');return}
    if(b<a){const t=a;a=b;b=t}
    const title=$('exTitle').value.trim()||'Exam';
    let n=0;const d=parseD(a);
    while(dstr(d)<=b&&n<62){const ds=dstr(d);const rr=getRec(ds);rr.status='exam';rr.examTitle=title;n++;d.setDate(d.getDate()+1)}
    save();renderCal();toast('📝 '+n+' exam day'+(n===1?'':'s')+' added ✓');
  };
  $('prepAuto').onclick=()=>{const n=autoFillPrep();renderCal();toast(n?n+' prep leave day'+(n===1?'':'s')+' marked ✓':'Nothing to fill — add 2+ exams first')};
  $('tab-calendar').querySelectorAll('[data-ds]').forEach(b=>b.onclick=()=>openSheet(b.dataset.ds));
}
/* ---- day bottom-sheet ---- */
function openSheet(ds){
  UI.sheetDate=ds;
  const sch=schedFor(ds),r=getRec(ds);
  const res=dayResult(ds);
  let badge='';
  if(!res.excluded&&!res.unmarked){
    badge=res.absent.length===0?'<span class="statuspill">✅ Attended</span>':res.present.length===0?'<span class="statuspill" style="background:rgba(255,107,139,.14);color:var(--red)">❌ Missed</span>':'<span class="statuspill" style="background:rgba(124,134,255,.14);color:#c9d2ff">◐ Partial</span>';
  }else if(res.excluded){const lbl={closed:'🏫 College closed',holiday:'🎉 Holiday',exam:'📝 Exam day',prepleave:'📚 Prep leave'}[res.reason]||esc(res.reason||'excluded');badge='<span class="statuspill" style="background:#232f5c;color:#9aa3c7">'+lbl+'</span>'}
  const n=sch.length+(r.extra?r.extra.length:0);
  let h='<h2 style="font-size:20px">'+fmtD(ds)+'</h2><p class="mut">'+n+' class'+(n===1?'':'es')+' scheduled</p>'+badge;
  h+='<button class="optbtn'+(r.status==='attended'?' on':'')+'" data-s="attended"><span class="e">✅</span><span><b>Attended all</b><span>Every class counted as present</span></span></button>';
  h+='<button class="optbtn'+(r.status==='missed'?' on':'')+'" data-s="missed"><span class="e">❌</span><span><b>Missed all</b><span>'+n+' classes missed</span></span></button>';
  h+='<button class="optbtn" data-s="some"><span class="e">⚠️</span><span><b>Missed some classes</b><span>Slide OFF the ones you missed</span></span></button>';
  h+='<button class="optbtn'+(r.status==='closed'?' on':'')+'" data-s="closed"><span class="e">🏫</span><span><b>College closed</b><span>Whole day excluded</span></span></button>';
  h+='<button class="optbtn'+(r.status==='holiday'?' on':'')+'" data-s="holiday"><span class="e">🎉</span><span><b>Personal off / holiday</b><span>Whole day excluded</span></span></button>';
  h+='<button class="optbtn'+(r.status==='exam'?' on':'')+'" data-s="exam"><span class="e">📝</span><span><b>Exam day</b><span>Whole day excluded</span></span></button>';
  h+='<button class="optbtn'+(r.status==='prepleave'?' on':'')+'" data-s="prepleave"><span class="e">📚</span><span><b>Preparatory leave</b><span>Whole day excluded</span></span></button>';
  if(r.status==='exam')h+='<div style="margin-top:10px"><label class="lbl">Exam name</label><input id="examTitleInp" placeholder="e.g. PHL End-sem" value="'+esc(r.examTitle||'')+'"></div>';
  h+='<div id="sheetPick" hidden style="margin-top:8px"></div>';
  h+='<div id="sheetExtras" style="margin-top:6px">'+((r.extra||[]).map(extraRowHTML).join(''))+'</div>';
  h+='<button class="btn sm" id="sheetAddX">＋ Add extra class</button>';
  h+='<button class="btn ghost sm" id="sheetClear">↩️ Clear this day</button>';
  h+='<button class="btn ghost sm" id="sheetClose">Close</button>';
  $('sheet').innerHTML=h;$('sheetWrap').hidden=false;
  $('sheetWrap').onclick=e=>{if(e.target.id==='sheetWrap')$('sheetWrap').hidden=true};
  $('sheetClose').onclick=()=>$('sheetWrap').hidden=true;
  const eti=$('examTitleInp');if(eti)eti.onchange=()=>{getRec(ds).examTitle=eti.value.trim()||'Exam';save()};
  $('sheet').querySelectorAll('[data-s]').forEach(b=>b.onclick=()=>{
    const v=b.dataset.s,rr=getRec(ds);
    if(v==='some'){
      const box=$('sheetPick');box.hidden=false;
      const tmp={};
      sch.forEach(p=>{
        let e;
        if(rr.status==='attended')e=true;else if(rr.status==='missed')e=false;
        else e=rr.marks[p.id]===false?false:true;
        tmp[p.id]=e;
      });
      const paint=()=>{
        let np=0,nm=0;Object.keys(tmp).forEach(k=>{tmp[k]?np++:nm++});
        box.innerHTML='<div class="hint">🟢 All start as <b>Present</b> — just <b>slide OFF ⬅ the ones you missed</b>, then Save.<br><b>✓ '+np+' present · ✕ '+nm+' missed</b></div>'
        +sch.map((p,i)=>{
          const c=subjColor(effSubj(p));const on=tmp[p.id];
          return '<div class="clsrow"><span class="numb" style="background:'+c+'">'+(i+1)+'</span><div class="inf"><b>'+esc(effSubj(p))+'</b><div>'+p.start+'–'+p.end+(p.periods>1?' · counts as 1':'')+'</div></div>'
          +'<div class="swwrap"><button class="sw '+(on?'on':'off')+'" data-pick="'+p.id+'"><span class="knob"></span></button><span class="swlab '+(on?'present':'missed')+'">'+(on?'Present':'Missed')+'</span></div></div>'
        }).join('')
        +'<div class="row2"><button class="btn primary sm" id="pickSave">💾 Save</button><button class="btn ghost sm" id="pickCancel">Cancel</button></div>';
        box.querySelectorAll('[data-pick]').forEach(t=>t.onclick=()=>{tmp[t.dataset.pick]=!tmp[t.dataset.pick];paint()});
        $('pickSave').onclick=()=>{Object.keys(tmp).forEach(k=>{rr.marks[k]=tmp[k]});rr.status=undefined;save();afterSheet(ds)};
        $('pickCancel').onclick=()=>{box.hidden=true};
      };
      paint();
      if(box.scrollIntoView)box.scrollIntoView();
      return;
    }
    rr.status=v;if(v==='attended'||v==='missed')rr.marks={};
    save();afterSheet(ds);
  });
  bindExtraList($('sheet'),ds,()=>openSheet(ds));
  $('sheetAddX').onclick=()=>openExtraModal(ds,()=>openSheet(ds));
  $('sheetClear').onclick=()=>{delete S.attendance[ds];save();afterSheet(ds)};
}
function afterSheet(ds){$('sheetWrap').hidden=true;if(UI.tab==='calendar')renderCal();if(UI.tab==='schedule')renderSched();if(UI.tab==='today')renderToday();renderDash0();toast('Saved ✓')}
function renderDash0(){/* keep dashboard fresh */}

/* ================= SCHEDULE ================= */
function mondayOf(ds){const d=parseD(ds);const off=(d.getDay()+6)%7;d.setDate(d.getDate()-off);return d}
function renderSched(){
  refreshHead();
  const mon=mondayOf(todayStr());
  const wkStr='Week of '+mon.getDate()+' '+mon.toLocaleDateString('en-IN',{month:'short',year:'numeric'});
  let h='<div class="card"><h4>Your weekly timetable <span style="float:right;text-transform:none;letter-spacing:0">(auto-built from your upload)</span></h4><p class="mut">'+wkStr+'</p><div class="schedscroll">';
  for(let i=0;i<7;i++){
    const d=new Date(mon);d.setDate(mon.getDate()+i);const ds=dstr(d);
    const dn=dowLong(ds);const arr=dayPeriods(dn);const on=S.dayEnabled[dn]!==false;
    h+='<div class="dcol'+(ds===todayStr()?' today':'')+'" data-ds="'+ds+'"><div class="dh">'+dn.toUpperCase()+'</div><div class="dn">'+d.getDate()+'</div>';
    const st0=rec(ds);
    if(st0&&st0.status==='exam')h+='<div class="mcard" style="border-color:#a855f7;background:rgba(168,85,247,.15)">📝 Exam</div>';
    else if(st0&&st0.status==='prepleave')h+='<div class="mcard" style="border-color:#38bdf8;background:rgba(56,189,248,.12)">📚 Prep</div>';
    if(!on||!arr.length){h+='<div class="mcard free">no class</div>'}
    else arr.forEach(p=>{
      if(p.type==='break'){h+='<div class="mcard lunch">'+esc(p.subject||'LUNCH')+'<br>'+p.start+'–'+p.end+'<br>LUNCH</div>';return}
      if(p.type!=='class'||!effSubj(p)){h+='<div class="mcard free">free</div>';return}
      const c=subjColor(effSubj(p));
      h+='<div class="mcard" style="border-color:'+c+'66;background:'+c+'1c"><b>'+esc(effSubj(p))+'</b>'+p.start+'–'+p.end+' · '+fmtDur(durMin(p.start,p.end))+(p.labOptions&&p.labOptions.length?'<br><span class="yl">✓ your lab</span>':'')+'</div>';
    });
    h+='</div>';
  }
  h+='</div><p class="small" style="margin-top:8px">Tap any day column to mark its attendance. Free slots show as <b>free</b>.</p></div>';
  // this week so far
  let T=0,A=0,M=0;
  for(let i=0;i<7;i++){const d=new Date(mon);d.setDate(mon.getDate()+i);const ds=dstr(d);if(ds>todayStr())continue;
    const res=dayResult(ds);if(res.excluded||res.unmarked)continue;T+=res.present.length+res.absent.length;A+=res.present.length;M+=res.absent.length}
  h+='<div class="card"><h4>This week so far</h4><div class="statline"><span>Classes so far this week</span><b>'+T+'</b></div><div class="statline"><span>Attended</span><b class="g">'+A+'</b></div><div class="statline"><span>Missed</span><b class="r">'+M+'</b></div></div>';
  $('tab-schedule').innerHTML=h;
  $('tab-schedule').querySelectorAll('.dcol').forEach(c=>c.onclick=()=>openSheet(c.dataset.ds));
}

/* ================= SETTINGS ================= */
const FESTIVALS=[['08-15','Independence Day'],['10-02','Gandhi Jayanti'],['12-25','Christmas Day'],['01-26','Republic Day']];
function renderSettings(){
  refreshHead();
  const wc=weekClasses(),ad=activeDays(),subs=allSubjects();
  let h='<div class="card"><h4>Semester</h4>'
    +'<div class="setrow"><div class="lab"><b>Semester start</b><span>Attendance counts from here</span></div><input type="date" id="sStart" value="'+S.semesterStart+'"></div>'
    +'<div class="setrow"><div class="lab"><b>Semester end</b><span>Planned last day</span></div><input type="date" id="sEnd" value="'+S.semesterEnd+'"></div>'
    +'<div class="setrow"><div class="lab"><b>Target %</b><span>Minimum you want to keep</span></div><input type="number" id="sTarget" min="1" max="100" value="'+S.target+'"></div></div>';
  h+='<div class="card"><h4>Timetable</h4><p style="font-size:15px"><b>'+wc+' classes / week</b> <span class="mut">on '+ad.join(', ')+'</span></p><p class="mut">'+subs.length+' subjects · '+S.holidays.length+' holidays saved</p>'
    +'<button class="btn" id="sEdit">✏️ Edit timetable</button>'
    +'<button class="btn" id="sXLSX">⬇ Timetable as Excel (.xlsx)</button>'
    +'<button class="btn ghost" id="sCSV">⬇ Timetable as CSV</button>'
    +'<button class="btn" id="sUp">🔄 Upload a different timetable file</button>'
    +'<div class="row2"><button class="btn sm ghost" id="sSample">⬇ Sample file</button><button class="btn sm ghost" id="sTemplate">⬇ Empty template</button></div></div>';
  h+='<div class="card"><h4>Holidays (excluded from counts)</h4><div id="holList">'
    +(S.holidays.length?S.holidays.map((x,i)=>'<div class="holrow"><span>📅 '+x.date+' — <b>'+esc(x.name)+'</b></span><button data-hol="'+i+'">✕</button></div>').join(''):'<p class="mut">No holidays yet — add one below.</p>')+'</div>'
    +'<div class="row2" style="margin-top:10px"><input type="date" id="holDate"><input id="holName" placeholder="Holiday name"></div><button class="btn primary sm" id="holAdd">Add</button>'
    +'<button class="btn ghost sm" id="holFest">🎉 Add Indian festival holidays for this semester</button></div>';
  h+='<div class="card"><h4>Data</h4><button class="btn" id="dExp">📤 Export backup (JSON)</button><button class="btn" id="dImp">📥 Import backup</button><button class="btn red" id="dReset">🗑 Reset everything</button>'
    +'<p class="mut" style="margin-top:12px"><b class="hl">How it counts:</b> every period in your timetable = 1 class — a merged 110-min lab also counts as 1. Days with no classes, weekends, holidays, exam days, prep leaves, and days you mark closed are excluded. Days you don\'t mark are not counted yet. Extra classes are included in all totals.</p></div>';
  h+='<div id="editWrap"></div>';
  $('tab-settings').innerHTML=h;
  $('sStart').onchange=e=>{S.semesterStart=e.target.value;save();refreshHead()};
  $('sEnd').onchange=e=>{S.semesterEnd=e.target.value;save();refreshHead()};
  $('sTarget').onchange=e=>{S.target=Math.max(1,Math.min(100,+e.target.value||75));save()};
  $('sXLSX').onclick=exportCurrentExcel;$('sCSV').onclick=exportCurrentCSV;
  $('sSample').onclick=downloadSample;$('sTemplate').onclick=downloadTemplate;
  $('sUp').onclick=()=>$('fileUp2').click();
  $('sEdit').onclick=()=>{
    genModal('<h3>✏️ Edit timetable</h3><div id="editBox"></div><button class="btn primary" id="editDone">Done</button>');
    UI.edCtx='settings';renderEditor($('editBox'));
    $('editDone').onclick=()=>{closeGen();renderSettings()};
  };
  $('tab-settings').querySelectorAll('[data-hol]').forEach(b=>b.onclick=()=>{S.holidays.splice(+b.dataset.hol,1);save();renderSettings()});
  $('holAdd').onclick=()=>{const d=$('holDate').value,n=$('holName').value.trim()||'Holiday';if(!d){toast('Pick a date');return}S.holidays.push({date:d,name:n});save();renderSettings()};
  $('holFest').onclick=()=>{
    const y=parseD(S.semesterStart).getFullYear();let n=0;
    FESTIVALS.forEach(([md,name])=>{[y,y+1].forEach(yy=>{const ds=yy+'-'+md;if(ds>=S.semesterStart&&ds<=S.semesterEnd&&!S.holidays.some(h=>h.date===ds)){S.holidays.push({date:ds,name});n++}})});
    save();renderSettings();toast(n?n+' holidays added ✓':'Already added');
  };
  $('dExp').onclick=()=>downloadFile('attendance-backup.json',JSON.stringify(S),'application/json',false);
  $('dImp').onclick=()=>$('fileJson').click();
  $('dReset').onclick=()=>genModal('<h3>Reset everything?</h3><p class="mut">This erases your timetable, attendance and holidays on this device.</p><button class="btn red" id="rYes">Yes, reset</button><button class="btn ghost sm" id="rNo">Cancel</button>',()=>{
    $('rYes').onclick=()=>{localStorage.removeItem('attCalcV1');location.reload()};$('rNo').onclick=closeGen;
  });
}
function genModal(html,after){$('genBox').innerHTML=html;$('genWrap').hidden=false;$('genWrap').onclick=e=>{if(e.target.id==='genWrap')closeGen()};after&&after()}
function closeGen(){$('genWrap').hidden=true}

/* ================= INIT ================= */
function showApp(){$('wizard').hidden=true;$('app').hidden=false;setTab('dashboard')}
function showWizard(){$('wizard').hidden=false;$('app').hidden=true;goStep(1)}
window.addEventListener('DOMContentLoaded',()=>{
  try{
  var sp=document.getElementById('splash');if(sp)sp.style.display='none';
  S=load()||blankState();
  if(!S.timetable||!Object.keys(S.timetable).length)blankWeek();
  try{ // one-time cleanup: free-slot markers wrongly saved as classes
    let fixed=0;
    DAYS.forEach(d=>(S.timetable[d]||[]).forEach(p=>{if(p.type==='class'&&isFreeMark(p.raw||p.subject)){p.subject='';p.raw='';retype(p);fixed++}}));
    if(fixed){save();setTimeout(()=>toast('Cleaned '+fixed+' free slot'+(fixed===1?'':'s')+' — no longer counted ✓'),800)}
  }catch(e){}
  document.querySelectorAll('#bottomNav button').forEach(b=>b.onclick=()=>setTab(b.dataset.tab));
  $('btnPick').onclick=()=>$('fileUp').click();
  $('fileUp').onchange=e=>{handleFile(e.target.files[0]);e.target.value=''};
  $('fileUp2').onchange=e=>{const f=e.target.files[0];e.target.value='';if(!f)return;
    const rd=new FileReader();rd.onload=ev=>{try{const wb=XLSX.read(ev.target.result,{type:'array'});parseWorkbook(wb);save();toast('Timetable replaced ✓');renderSettings();genModal('<h3>✏️ Check the new timetable</h3><div id="editBox2"></div><button class="btn primary" id="editDone2">Looks good — save</button>');renderEditor($('editBox2'));$('editDone2').onclick=()=>{closeGen();renderSettings()}}catch(ex){toast('❌ '+(ex.message||'Could not read file'))}};rd.readAsArrayBuffer(f)};
  $('fileJson').onchange=e=>{const f=e.target.files[0];e.target.value='';if(!f)return;const rd=new FileReader();rd.onload=ev=>{try{S=JSON.parse(ev.target.result);save();toast('Backup restored ✓');showApp()}catch(x){toast('❌ Invalid backup file')}};rd.readAsText(f)};
  $('btnSample').onclick=downloadSample;$('btnTemplate').onclick=downloadTemplate;
  $('btnManual').onclick=()=>{blankWeek();save();goStep(2)};
  $('wBack2').onclick=()=>goStep(1);$('wNext2').onclick=()=>{save();goStep(3)};
  $('wBack3').onclick=()=>goStep(2);
  $('wFinish').onclick=()=>{
    S.semesterStart=$('semStart').value||S.semesterStart;S.semesterEnd=$('semEnd').value||S.semesterEnd;S.target=+($('semTarget').value)||75;
    S.setupDone=true;save();showApp();toast('All set — mark your attendance ✓');
  };
  if(S.setupDone)showApp();else showWizard();
  if(window.AndroidBridge&&window.AndroidBridge.booted){try{window.AndroidBridge.booted()}catch(e){}}
  }catch(err){
    var s=document.getElementById('splash');if(s){s.style.display='flex';s.innerHTML='<div class="logo">⚠️</div><h2>Startup failed</h2><p>'+esc(String((err&&err.message)||err))+'<br><br>Please screenshot this and share it.</p>'}
    throw err;
  }
});
