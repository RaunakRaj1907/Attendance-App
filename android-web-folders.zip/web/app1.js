/* ================= STATE & UTILS ================= */
const DAYS=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
const DAYMAP={mon:'Mon',monday:'Mon',tue:'Tue',tues:'Tue',tuesday:'Tue',wed:'Wed',wednesday:'Wed',thu:'Thu',thur:'Thu',thurs:'Thu',thursday:'Thu',fri:'Fri',friday:'Fri',sat:'Sat',saturday:'Sat',sun:'Sun',sunday:'Sun'};
const PALETTE=['#8b9dff','#2dd4a6','#fbbf24','#f472b6','#22d3ee','#c4b5fd','#fb923c','#a3e635','#f87171','#7dd3fc'];
const DEF_TIMES=[['8:15','9:10'],['9:10','10:05'],['10:05','11:00'],['11:00','11:30'],['11:30','12:25'],['12:25','1:20'],['1:20','2:15'],['2:15','3:10']];
let S=null; // state
let UI={tab:'dashboard',calY:0,calM:0,todayDate:'',sheetDate:'',edCtx:'wizard'};

function $(id){return document.getElementById(id)}
function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
function toast(m){const t=$('toast');t.textContent=m;t.classList.add('show');clearTimeout(t._h);t._h=setTimeout(()=>t.classList.remove('show'),2400)}
function uid(p){return (p||'id')+'-'+Math.random().toString(36).slice(2,9)}
function pad(n){return (n<10?'0':'')+n}
function todayStr(){const d=new Date();return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())}
function dstr(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())}
function parseD(s){const[a,b,c]=s.split('-').map(Number);return new Date(a,b-1,c)}
function fmtD(s){return parseD(s).toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}
function fmtDs(s){return parseD(s).toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short'})}
function dowLong(s){return ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][parseD(s).getDay()]}
function dowIdx(s){return (parseD(s).getDay()+6)%7} // Mon=0
function subjColor(n){n=String(n||'?').toUpperCase();let h=0;for(const c of n)h=(h*31+c.charCodeAt(0))>>>0;return PALETTE[h%PALETTE.length]}
function normSub(s){return String(s||'').trim().replace(/\s+/g,' ').toUpperCase()}

/* ---- time helpers (school clock: 8..11 AM, 12 noon, 1..7 PM) ---- */
function tmin(t){const m=String(t||'').trim().match(/(\d{1,2})[:.](\d{2})/);if(!m)return null;let h=+m[1];const mi=+m[2];if(h>=8&&h<=11){}else if(h===12){}else if(h<8){h+=12}else if(h>12&&h<24){}else{h+=12}return h*60+mi}
function durMin(a,b){const x=tmin(a),y=tmin(b);if(x==null||y==null)return 55;let d=y-x;if(d<=0)d+=12*60;return d}
function fmtDur(m){m=Math.round(m);if(m<60)return m+' min';const h=Math.floor(m/60),r=m%60;return r?h+' hr '+r+' min':h+' hr'}

/* ---- subject classification ---- */
function isBreak(s){return /LUNCH|BREAK|RECESS|TEA|INTERVAL/.test(normSub(s))}
function isLabSubject(s){
  const n=normSub(s);if(!n||isBreak(n))return false;
  if(n.includes('/'))return true;
  if(/GRAPHIC|DRAWING|WORKSHOP|PRACTICAL|\bLAB\b|LABORATORY/.test(n))return true;
  if(/C[-\s]?LANG|C[-\s]?PROG|PROGRAMMING IN C|\bC LAB/.test(n))return true;
  const code=n.split(/[\s:]+/)[0];
  if(/^(EGL|EG|EGD|EDG|PCL|PCP|CPL|CSL|C LAB|EVSP|PHP|BEE|WSP|MEP|CSP)$/.test(code))return true;
  if(/^[A-Z]{2,5}P$/.test(code))return true; // ends with P = practical
  return false;
}
function splitLabOptions(raw){
  // "P1: EVSP / P2: PHP" -> [{label:'P1: EVSP',code:'EVSP'},{label:'P2: PHP',code:'PHP'}]
  return String(raw).split('/').map(s=>s.trim()).filter(Boolean).map(part=>{
    let code=part;const m=part.match(/:\s*(.+)$/);if(m)code=m[1].trim();
    code=code.replace(/\s*\(.*\)\s*$/,'').trim();
    return {label:part,code:code||part};
  });
}
function effSubj(p){
  if(!p)return '';
  if(p.labOptions&&p.labOptions.length){return p.labChoice||p.labOptions[0].code}
  return (p.subject||'').trim();
}

/* ---- persistence ---- */
function save(){try{localStorage.setItem('attCalcV1',JSON.stringify(S))}catch(e){}}
function load(){try{const r=localStorage.getItem('attCalcV1');return r?JSON.parse(r):null}catch(e){return null}}
function blankState(){
  const y=new Date().getFullYear();
  return {setupDone:false,semesterStart:y+'-08-17',semesterEnd:y+'-12-31',target:75,
    timetable:{},dayEnabled:{Mon:true,Tue:true,Wed:true,Thu:true,Fri:true,Sat:false,Sun:false},
    holidays:[],attendance:{}};
}

/* ---- timetable helpers ---- */
function dayPeriods(day){return (S.timetable[day]||[])}
function classPeriods(day){return dayPeriods(day).filter(p=>p.type==='class'&&effSubj(p))}
function dayClassCount(day){if(S.dayEnabled[day]===false)return 0;return classPeriods(day).length}
function weekClasses(){return DAYS.reduce((a,d)=>a+dayClassCount(d),0)}
function activeDays(){return DAYS.filter(d=>S.dayEnabled[d]!==false&&dayClassCount(d)>0)}
function allSubjects(){
  const set={};
  DAYS.forEach(d=>dayPeriods(d).forEach(p=>{if(p.type==='class'){const s=normSub(effSubj(p));if(s)set[s]=effSubj(p).trim()}}));
  Object.keys(S.attendance||{}).forEach(k=>{const r=S.attendance[k];(r.extra||[]).forEach(x=>{const s=normSub(x.subject);if(s)set[s]=x.subject.trim()})});
  return Object.keys(set).sort().map(k=>set[k]);
}
function weeklyPossible(sub){
  const n=normSub(sub);let c=0;
  DAYS.forEach(d=>{if(S.dayEnabled[d]===false)return;classPeriods(d).forEach(p=>{if(normSub(effSubj(p))===n)c++})});
  return c;
}
/* markers that mean "no class in this slot" — never counted */
const FREE_MARKERS=/^(FREE|FREES|-+|–+|—+|N\/A|NA|NIL|NONE|NO\s*CLASS|NOCLASS|X+|\.+|\/+|\\+|0+|_+|\*+|#N\/A|NULL|BLANK|EMPTY|OFF|HOLIDAY)$/i;
function isFreeMark(s){return FREE_MARKERS.test(String(s==null?'':s).trim())}
function mkPeriod(start,end,subject,extra){
  subject=String(subject==null?'':subject).trim();
  if(isFreeMark(subject))subject='';
  const p=Object.assign({id:uid('p'),start,end,subject,raw:subject,type:'class',periods:1,merged:false,labOptions:[],labChoice:'',weight:1},extra||{});
  if(!subject){p.type='free';p.weight=0}
  else if(isBreak(subject)){p.type='break';p.weight=0}
  else if(subject.includes('/')){p.labOptions=splitLabOptions(subject);p.labChoice=p.labOptions[0]?p.labOptions[0].code:'';p.type='class';p.weight=1}
  return p;
}
function retype(p){
  let s=(p.subject||'').trim();
  if(isFreeMark(s)){s='';p.subject='';p.raw=''}
  if(!s){p.type='free';p.weight=0;p.labOptions=[];p.labChoice=''}
  else if(isBreak(s)){p.type='break';p.weight=0;p.labOptions=[];p.labChoice=''}
  else{p.type='class';p.weight=1;
    if(s.includes('/')){p.labOptions=splitLabOptions(s);if(!p.labOptions.some(o=>o.code===p.labChoice))p.labChoice=p.labOptions[0].code}
    else{p.labOptions=[];p.labChoice=''}
  }
}
function tryAutoMerge(day){
  // merge consecutive duplicate LAB subjects into one 110-min block (attendance = 1)
  const arr=S.timetable[day];if(!arr||arr.length<2)return;
  const out=[];
  for(let i=0;i<arr.length;i++){
    const a=arr[i],b=arr[i+1];
    if(b&&a.type==='class'&&b.type==='class'&&!a.labOptions.length&&!b.labOptions.length
      &&normSub(a.subject)&&normSub(a.subject)===normSub(b.subject)
      &&isLabSubject(a.subject)&&a.periods===1&&b.periods===1){
      out.push(Object.assign({},a,{id:uid('p'),end:b.end,periods:2,merged:true,autoMerged:true,weight:1}));
      i++;
    }else out.push(a);
  }
  S.timetable[day]=out;
}

/* ================= EXCEL PARSING (Excel only, no image/PDF) ================= */
function parseTimeCell(v){
  if(v==null)return null;
  if(typeof v==='number'&&isFinite(v)){ // excel fraction of day?
    if(v>0&&v<1){const m=Math.round(v*24*60);return {h:Math.floor(m/60),m:m%60}}
    return null;
  }
  let s=String(v).trim().replace(/–|—|−/g,'-').replace(/\bto\b/i,'-');
  const m=s.match(/(\d{1,2})[:.](\d{2})\s*(AM|PM|am|pm)?\s*-\s*(\d{1,2})[:.](\d{2})\s*(AM|PM|am|pm)?/);
  if(m){
    let h1=+m[1],h2=+m[4];const ap1=(m[3]||'').toUpperCase(),ap2=(m[6]||'').toUpperCase();
    const conv=(h,ap,other)=>{if(ap==='PM'&&h<12)return h+12;if(ap==='AM'&&h===12)return 0;if(!ap&&other==='PM'&&h<12)return h+12;return h};
    h1=conv(h1,ap1,ap2);h2=conv(h2,ap2,ap1);
    const f=h=>(h>12?h-12:h);
    return {a:f(h1)+':'+pad(+m[2]),b:f(h2)+':'+pad(+m[5])};
  }
  const s2=s.match(/(\d{1,2})[:.](\d{2})/); // single time -> assume 55 min
  if(s2){let h=+s2[1];const mi=+s2[2];const start=(h>12?h-12:h)+':'+pad(mi);const tot=h*60+mi+55;const e=(Math.floor(tot/60)>12?Math.floor(tot/60)-12:Math.floor(tot/60))+':'+pad(tot%60);return {a:start,b:e}}
  return null;
}
function parseWorkbook(wb){
  const ws=wb.Sheets[wb.SheetNames[0]];
  const grid=XLSX.utils.sheet_to_json(ws,{header:1,defval:'',raw:true,blankrows:false});
  if(!grid.length)throw new Error('Empty sheet');
  // find header row: row with >=2 time-like cells
  let hr=-1,tc=-1;
  for(let r=0;r<Math.min(grid.length,6);r++){
    let cnt=0,first=-1;
    for(let c=0;c<grid[r].length;c++){if(parseTimeCell(grid[r][c])){cnt++;if(first<0)first=c}}
    if(cnt>=2){hr=r;tc=first;break}
  }
  if(hr<0)throw new Error('No time-slot header row found. Put time slots like 8:15-9:10 in the first row.');
  const times=[];
  for(let c=tc;c<grid[hr].length;c++){const t=parseTimeCell(grid[hr][c]);if(t)times.push(Object.assign({col:c},t));else if(times.length)break}
  if(times.length<1)throw new Error('Could not read time slots from the first row.');
  // merges map
  const merges=(ws['!merges']||[]).map(m=>({rs:m.s.r,cs:m.s.c,re:m.e.r,ce:m.e.c}));
  const mergeAt=(r,c)=>merges.find(m=>r>=m.rs&&r<=m.re&&c>=m.cs&&c<=m.ce);
  // day column: usually tc-1; find best col with day names
  let dayCol=tc-1;let best=-1;
  for(let c=0;c<tc+1&&c<4;c++){let n=0;for(let r=hr+1;r<grid.length;r++){const v=String(grid[r][c]||'').trim().toLowerCase().split(/[\s/]+/)[0];if(DAYMAP[v])n++}if(n>best){best=n;dayCol=c}}
  const tt={};DAYS.forEach(d=>tt[d]=[]);
  const enabled={};DAYS.forEach(d=>enabled[d]=false);
  let found=0;
  for(let r=hr+1;r<grid.length;r++){
    const dv=String(grid[r][dayCol]||'').trim().toLowerCase().split(/[\s/]+/)[0];
    const day=DAYMAP[dv];if(!day)continue;
    found++;
    const skipUntil={v:-1};
    for(let ti=0;ti<times.length;ti++){
      const col=times[ti].col;if(col<=skipUntil.v)continue;
      const mg=mergeAt(r,col);
      if(mg&&!(mg.rs===r&&mg.cs===col))continue; // covered by merge, skip
      let endTi=ti,raw=grid[r][col];
      if(mg&&(mg.ce>mg.cs)){ // merged across time cols
        while(endTi+1<times.length&&times[endTi+1].col<=mg.ce)endTi++;
        skipUntil.v=mg.ce;
      }
      raw=(raw==null?'':String(raw)).trim();
      const p=mkPeriod(times[ti].a,times[endTi].b,raw);
      if(endTi>ti){p.periods=endTi-ti+1;p.merged=true}
      tt[day].push(p);
    }
    enabled[day]=true;
  }
  if(!found)throw new Error('No day rows (MON…SUN) found in the first column.');
  S.timetable=tt;S.dayEnabled=enabled;
  DAYS.forEach(d=>{ // fill missing days with default skeleton
    if(!S.timetable[d].length){S.timetable[d]=DEF_TIMES.map(t=>mkPeriod(t[0],t[1],(t[0]==='11:00'?'LUNCH':'')));if(S.dayEnabled[d]===undefined)S.dayEnabled[d]=false}
  });
  DAYS.forEach(tryAutoMerge);
  return {days:Object.keys(enabled).filter(k=>enabled[k])};
}
function handleFile(file){
  const msg=$('parseMsg');
  const ok=m=>{msg.innerHTML='<div class="hint" style="border-color:var(--grn)">✅ '+m+'</div>'};
  const err=m=>{msg.innerHTML='<div class="hint" style="border-color:var(--red);color:#ffb3c4">❌ '+esc(m)+'</div>'};
  if(!file)return;
  if(!/\.(xlsx|xls|csv)$/i.test(file.name)){err('Only Excel files (.xlsx, .xls, .csv) are supported.');return}
  msg.innerHTML='<div class="hint">⏳ Reading <b>'+esc(file.name)+'</b>…</div>';
  const rd=new FileReader();
  rd.onload=e=>{
    try{
      const wb=XLSX.read(e.target.result,{type:'array'});
      const r=parseWorkbook(wb);
      save();ok('Timetable loaded: <b>'+r.days.join(', ')+'</b> — '+weekClasses()+' classes/week. Check it in the next step →');
      setTimeout(()=>goStep(2),650);
    }catch(ex){err(ex.message||'Could not read this file. Try the Empty template.')}
  };
  rd.onerror=()=>err('Could not read the file.');
  rd.readAsArrayBuffer(file);
}

/* ================= SAMPLE & TEMPLATE ================= */
const SAMPLE_TIMES=['8:15-9:10','9:10-10:05','10:05-11:00','11:00-11:30','11:30-12:25','12:25-1:20','1:20-2:15','2:15-3:10'];
const SAMPLE_ROWS=[
  ['MON','PHL','MPL','MAL','LUNCH','CSL','EVSL','P1: EVSP / P2: PHP',''],
  ['TUE','','EVSL','MPL','LUNCH','PCL','','',''],
  ['WED','','P2: EVSP / P1: PHP','','LUNCH','MAL','CSL','EGL','EGL'],
  ['THU','PHL','PCP','PCP','LUNCH','PCL','MPL','PD',''],
  ['FRI','PHL','MPL','MAL','LUNCH','C Language Lab','C Language Lab','PD','']
];
function buildAOA(rows){return [['Day / Time'].concat(SAMPLE_TIMES)].concat(rows)}
function downloadFile(name,content,mime,isBase64){
  try{
    if(window.AndroidBridge&&window.AndroidBridge.saveFile){
      let b64=isBase64?content:btoa(unescape(encodeURIComponent(content)));
      window.AndroidBridge.saveFile(b64,name,mime||'application/octet-stream');
      toast('Saved '+name);return;
    }
  }catch(e){}
  const blob=isBase64?b64toBlob(content,mime):new Blob([content],{type:mime||'text/plain'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();
  setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},800);
}
function b64toBlob(b64,mime){const bin=atob(b64);const arr=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)arr[i]=bin.charCodeAt(i);return new Blob([arr],{type:mime||'application/octet-stream'})}
function aoaMerged(aoa,mergeList){
  const ws=XLSX.utils.aoa_to_sheet(aoa);ws['!merges']=mergeList;
  ws['!cols']=[{wch:12}].concat(SAMPLE_TIMES.map(()=>({wch:16})));
  return ws;
}
function downloadSample(){
  const aoa=buildAOA(SAMPLE_ROWS.map(r=>r.slice()));
  const ws=aoaMerged(aoa,[{s:{r:1,c:7},e:{r:1,c:8}},{s:{r:3,c:2},e:{r:3,c:3}}]);
  const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'Timetable');
  const b64=XLSX.write(wb,{bookType:'xlsx',type:'base64'});
  downloadFile('sample-timetable.xlsx',b64,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',true);
}
function downloadTemplate(){
  const rows=DAYS.slice(0,6).map(d=>[d.toUpperCase(),'','','','','','','','']);
  const ws=aoaMerged(buildAOA(rows),[]);
  const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'Timetable');
  const b64=XLSX.write(wb,{bookType:'xlsx',type:'base64'});
  downloadFile('empty-timetable-template.xlsx',b64,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',true);
}
function exportCurrentExcel(){
  const head=['Day / Time'];const maxC=Math.max.apply(null,DAYS.map(d=>dayPeriods(d).length).concat([1]));
  // rebuild columns from Mon..Sun union: use per-day own times; export uses each day's own slots
  const aoa=[];const merges=[];let maxCols=0;
  DAYS.forEach(d=>{maxCols=Math.max(maxCols,dayPeriods(d).length)});
  const hrow=['Day / Time'];
  // use first non-empty day's slots as header
  const ref=DAYS.map(d=>dayPeriods(d)).find(a=>a.length)||[];
  ref.forEach(p=>hrow.push(p.start+'-'+p.end));
  aoa.push(hrow);
  DAYS.forEach((d,di)=>{
    const row=[d.toUpperCase()];const arr=dayPeriods(d);
    arr.forEach((p,pi)=>{row.push(p.type==='free'?'':(p.raw||p.subject||''))});
    aoa.push(row);
  });
  const ws=XLSX.utils.aoa_to_sheet(aoa);
  ws['!cols']=[{wch:12}].concat(ref.map(()=>({wch:18})));
  const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'Timetable');
  downloadFile('my-timetable.xlsx',XLSX.write(wb,{bookType:'xlsx',type:'base64'}),'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',true);
}
function exportCurrentCSV(){
  const ref=DAYS.map(d=>dayPeriods(d)).find(a=>a.length)||[];
  let csv='Day / Time,'+ref.map(p=>'"'+p.start+'-'+p.end+'"').join(',')+'\n';
  DAYS.forEach(d=>{csv+=d.toUpperCase()+','+dayPeriods(d).map(p=>'"'+String(p.type==='free'?'':(p.raw||p.subject||'')).replace(/"/g,'""')+'"').join(',')+'\n'});
  downloadFile('my-timetable.csv',csv,'text/csv',false);
}
function loadSampleIntoState(){
  const tt={};
  SAMPLE_ROWS.forEach(r=>{
    const day=DAYMAP[r[0].toLowerCase()];tt[day]=[];
    const cells=r.slice(1);
    for(let i=0;i<SAMPLE_TIMES.length;i++){
      const t=SAMPLE_TIMES[i].split('-');
      tt[day].push(mkPeriod(t[0],t[1],cells[i]||''));
    }
  });
  // replicate the merged cells from the sample sheet
  S.timetable=tt;
  S.dayEnabled={Mon:true,Tue:true,Wed:true,Thu:true,Fri:true,Sat:false,Sun:false};
  // Mon G-H merged slash lab
  S.timetable['Mon']=mergeIdx('Mon',6,7);S.timetable['Wed']=mergeIdx('Wed',1,2);
  DAYS.forEach(d=>{if(!S.timetable[d])S.timetable[d]=DEF_TIMES.map(t=>mkPeriod(t[0],t[1],t[0]==='11:00'?'LUNCH':''))});
  DAYS.forEach(tryAutoMerge);
  function mergeIdx(d,a,b){const arr=S.timetable[d];const p=mkPeriod(arr[a].start,arr[b].end,arr[a].subject);p.periods=b-a+1;p.merged=true;const out=arr.slice(0,a).concat([p],arr.slice(b+1));return out}
}
