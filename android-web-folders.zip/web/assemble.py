#!/usr/bin/env python3
"""Assemble the single-file web app (index.html) from the sources in web/.

Usage:
    python3 web/assemble.py        # writes index.html at the repo root
"""
import pathlib

WEB = pathlib.Path(__file__).parent

top = (WEB / 'top.html').read_text(encoding='utf-8')
lib = (WEB / 'xlsx.min.js').read_text(encoding='utf-8')
a1 = (WEB / 'app1.js').read_text(encoding='utf-8')
a2 = (WEB / 'app2.js').read_text(encoding='utf-8')
a3 = (WEB / 'app3.js').read_text(encoding='utf-8')

assert '</script' not in lib.lower(), 'xlsx lib would break out of the script tag!'
assert '[hidden]{display:none!important}' in top, 'hidden-attribute fix missing!'

out = top + lib + '\n</script>\n<script>\n' + a1 + '\n' + a2 + '\n' + a3 + '\n</script>\n</body>\n</html>\n'
(WEB.parent / 'index.html').write_text(out, encoding='utf-8')
print(f'index.html written ({len(out.encode("utf-8"))} bytes)')
