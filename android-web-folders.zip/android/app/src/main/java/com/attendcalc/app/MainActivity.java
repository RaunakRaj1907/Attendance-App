package com.attendcalc.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final String HOME_URL = "file:///android_asset/www/index.html";
    private static final int FILE_REQ = 1001;

    private WebView web;
    private FrameLayout overlay;
    private TextView titleView;
    private TextView logView;
    private Button softBtn;
    private final StringBuilder logBuf = new StringBuilder();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean booted = false;
    private boolean softwareTried = false;
    private boolean softwareMode = false;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView.setWebContentsDebuggingEnabled(true);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0A1122"));

        web = createWebView();
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        overlay = buildOverlay();
        root.addView(overlay, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        setContentView(root);

        log("Device: " + Build.MANUFACTURER + " " + Build.MODEL + " (Android " + Build.VERSION.RELEASE + ", SDK " + Build.VERSION.SDK_INT + ")");
        log("WebView: " + webViewVersion());
        log("Loading app...");

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(HOME_URL);

        scheduleBootCheck(15000);
    }

    private FrameLayout buildOverlay() {
        FrameLayout ov = new FrameLayout(this);
        ov.setBackgroundColor(Color.parseColor("#0A1122"));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(44, 80, 44, 60);

        titleView = new TextView(this);
        titleView.setText("\uD83D\uDCCA Attendance Calculator");
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(20);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setGravity(Gravity.CENTER);
        col.addView(titleView);

        TextView sub = new TextView(this);
        sub.setText("Starting up... (this screen hides automatically)");
        sub.setTextColor(Color.parseColor("#8F99BF"));
        sub.setTextSize(13);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 10, 0, 20);
        col.addView(sub);

        ScrollView sv = new ScrollView(this);
        LinearLayout.LayoutParams svp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        logView = new TextView(this);
        logView.setTextColor(Color.parseColor("#C9D2FF"));
        logView.setTextSize(12);
        logView.setTypeface(Typeface.MONOSPACE);
        sv.addView(logView);
        col.addView(sv, svp);

        softBtn = mkBtn("Software render: OFF");
        softBtn.setOnClickListener(v -> {
            softwareMode = !softwareMode;
            applyRenderMode();
            rebootWeb("Manual switch: software render " + (softwareMode ? "ON" : "OFF"));
        });
        Button reloadBtn = mkBtn("\u27F3 Reload app");
        reloadBtn.setOnClickListener(v -> rebootWeb("Manual reload"));
        Button chromeBtn = mkBtn("Open in Chrome instead");
        chromeBtn.setOnClickListener(v -> openInChrome());

        col.addView(softBtn);
        col.addView(reloadBtn);
        col.addView(chromeBtn);

        ov.addView(col, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        return ov;
    }

    private Button mkBtn(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = 14;
        b.setLayoutParams(p);
        return b;
    }

    private void log(final String s) {
        handler.post(() -> {
            logBuf.append("\u2022 ").append(s).append("\n");
            if (logView != null) {
                logView.setText(logBuf.toString());
                final ScrollView sv = (ScrollView) logView.getParent();
                if (sv != null) sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
            }
        });
    }

    private String webViewVersion() {
        try {
            PackageInfo pi = WebViewCompat.getCurrentWebViewPackage(this);
            if (pi != null) return pi.packageName + " " + pi.versionName;
        } catch (Exception ignored) {}
        try {
            return getPackageManager().getPackageInfo("com.google.android.webview", 0).versionName;
        } catch (Exception ignored) {}
        return "unknown";
    }

    private WebView createWebView() {
        WebView w = new WebView(this);
        w.setBackgroundColor(Color.parseColor("#0A1122"));
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (softwareMode) w.setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        w.addJavascriptInterface(new Bridge(), "AndroidBridge");
        w.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                log("Page started: " + url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                log("Page loaded OK (" + view.getProgress() + "%) - waiting for app to start...");
                scheduleBootCheck(12000);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    String d = (Build.VERSION.SDK_INT >= 23 && error != null)
                            ? String.valueOf(error.getDescription()) : "unknown error";
                    int code = (Build.VERSION.SDK_INT >= 23 && error != null) ? error.getErrorCode() : -1;
                    log("LOAD ERROR #" + code + ": " + d);
                    handler.post(() -> titleView.setText("\u26A0\uFE0F Load failed - see details"));
                }
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                log("Renderer process gone (crashed=" + (detail != null && detail.didCrash()) + "). Recreating...");
                recreateWebView();
                return true;
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                if (m != null && m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    log("JS error: " + m.message() + " (line " + m.lineNumber() + ")");
                }
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try {
                    Intent i = params.createIntent();
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(Intent.createChooser(i, "Select timetable file"), FILE_REQ);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        return w;
    }

    private void applyRenderMode() {
        if (web != null) web.setLayerType(softwareMode ? View.LAYER_TYPE_SOFTWARE : View.LAYER_TYPE_HARDWARE, null);
        if (softBtn != null) softBtn.setText("Software render: " + (softwareMode ? "ON" : "OFF"));
    }

    private void rebootWeb(String why) {
        log(why);
        booted = false;
        handler.post(() -> {
            overlay.setVisibility(View.VISIBLE);
            titleView.setText("\uD83D\uDCCA Attendance Calculator");
        });
        web.loadUrl(HOME_URL);
        scheduleBootCheck(15000);
    }

    private void recreateWebView() {
        try {
            FrameLayout parent = (FrameLayout) web.getParent();
            if (parent == null) return;
            parent.removeView(web);
            web.destroy();
            booted = false;
            web = createWebView();
            parent.addView(web, 0, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            handler.post(() -> overlay.setVisibility(View.VISIBLE));
            web.loadUrl(HOME_URL);
            scheduleBootCheck(15000);
        } catch (Exception e) {
            log("Recreate failed: " + e.getMessage());
        }
    }

    private void scheduleBootCheck(long delayMs) {
        handler.removeCallbacks(bootCheck);
        handler.postDelayed(bootCheck, delayMs);
    }

    private final Runnable bootCheck = new Runnable() {
        @Override
        public void run() {
            if (booted) return;
            if (!softwareTried) {
                softwareTried = true;
                softwareMode = true;
                applyRenderMode();
                log("App did not respond - auto-switching to software rendering and reloading...");
                web.loadUrl(HOME_URL);
                scheduleBootCheck(15000);
            } else {
                log("Still no response. Please screenshot this screen and share it.");
                log("You can try Reload, or 'Open in Chrome' below.");
                handler.post(() -> titleView.setText("\u26A0\uFE0F App is not starting"));
            }
        }
    };

    private void openInChrome() {
        try {
            File dir = new File(getCacheDir(), "shared");
            dir.mkdirs();
            File out = new File(dir, "index.html");
            try (InputStream in = getAssets().open("www/index.html");
                 OutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
            Uri uri = FileProvider.getUriForFile(this, "com.attendcalc.app.files", out);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "text/html");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try {
                i.setPackage("com.android.chrome");
                startActivity(i);
            } catch (Exception e1) {
                i.setPackage(null);
                startActivity(Intent.createChooser(i, "Open app in browser"));
            }
            log("Opened in browser.");
        } catch (Exception e) {
            log("Open-in-Chrome failed: " + e.getMessage());
            Toast.makeText(this, "Could not open in browser: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_REQ) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                String ds = data.getDataString();
                if (ds != null) results = new Uri[]{Uri.parse(ds)};
            }
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web != null && booted && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    public class Bridge {
        @JavascriptInterface
        public void booted() {
            booted = true;
            handler.removeCallbacks(bootCheck);
            handler.post(() -> overlay.setVisibility(View.GONE));
        }

        @JavascriptInterface
        public void saveFile(final String base64, final String name, final String mime) {
            runOnUiThread(() -> {
                try {
                    byte[] data = Base64.decode(base64, Base64.DEFAULT);
                    String savedTo;
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                        v.put(MediaStore.Downloads.MIME_TYPE, mime);
                        v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AttendanceCalculator");
                        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                            os.write(data);
                        }
                        savedTo = "Downloads/AttendanceCalculator/" + name;
                    } else {
                        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AttendanceCalculator");
                        dir.mkdirs();
                        File f = new File(dir, name);
                        try (FileOutputStream fos = new FileOutputStream(f)) {
                            fos.write(data);
                        }
                        savedTo = f.getAbsolutePath();
                    }
                    Toast.makeText(MainActivity.this, "Saved: " + savedTo, Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }
    }
}
